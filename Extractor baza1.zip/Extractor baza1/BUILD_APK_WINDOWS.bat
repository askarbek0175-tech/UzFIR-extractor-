@echo off
chcp 65001 >nul
title UZFIR Radar DB Extractor — Сборка Android APK в 1 клик (HP Victus)
echo ============================================================================
echo   UZFIR / AvtoMaydon — Сборка Android APK для извлечения баз BIN/JSON/TXT
echo ============================================================================
echo.

cd /d "%~dp0flutter_extractor_app"

where flutter >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [!] Flutter не найден в PATH. Откройте папку flutter_extractor_app или android_studio_native_apk в Android Studio и нажмите Build -> Build APK.
    pause
    exit /b 1
)

echo [1/4] Инициализация Android-платформы...
call flutter create --platforms=android --org uz.uzfir.extractor --project-name uzfir_db_extractor .

echo [2/4] Подключение нативного модуля сохранения файлов в Загрузки Android...
if exist "android\app\src\main\kotlin\uz\uzfir\extractor\MainActivity.kt" (
    echo Нативный модуль MainActivity.kt подключен.
)

echo [3/4] Загрузка зависимостей...
call flutter pub get

echo [4/4] Сборка релизного файла APK...
call flutter build apk --release

echo.
echo ============================================================================
echo   ГОТОВО! Ваш APK собран по пути:
echo   flutter_extractor_app\build\app\outputs\flutter-apk\app-release.apk
echo ============================================================================
if exist "build\app\outputs\flutter-apk" (
    explorer "build\app\outputs\flutter-apk"
)
pause
