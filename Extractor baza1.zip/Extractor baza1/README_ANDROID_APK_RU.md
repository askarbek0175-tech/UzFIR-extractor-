# UZFIR Radar DB Extractor — Android APK & Windows 11

Этот архив содержит **две готовые версии Android-приложения** для извлечения и конвертации баз данных антирадаров (`.bin` / `.zip` -> чистый `_DB.bin`, `.json`, `SpeedCam.txt`, `iGO.txt`, `.csv`, `.gpx`, `.kml`):

1. **`flutter_extractor_app/` (Нативное Flutter-приложение для Android)**:
   - Внутри уже встроена актуальная база камер Узбекистана от **30.10.2026** (`8 961` точка).
   - Открывает любые файлы прошивок `.bin` и архивы `.zip` из памяти телефона или папки Telegram.
   - Напрямую сохраняет извлеченные файлы (`BIN`, `JSON`, `TXT`, `CSV`, `GPX`, `KML`) в папку телефона **`Download/UZFIR_Extractor/`** (без блокировок браузера!) и позволяет в 1 тап переслать их в Telegram.
   - Поддерживает русский (`RU`) и узбекский (`UZ Lotin`) языки, а также тёмную и светлую темы.

2. **`android_studio_native_apk/` (Нативный Java/WebView проект для Android Studio)**:
   - Если вы хотите точно такой же интерфейс, как в нашей HTML-программе, но в виде отдельного `.apk` с прямым сохранением файлов в папку `Download/UZFIR_Extractor/` через нативный мост `@JavascriptInterface`.

---

## Как собрать готовый `.apk` за 1 минуту на вашем ноутбуке HP Victus

### Способ А — В один клик (через `BUILD_APK_WINDOWS.bat`)
1. Распакуйте этот архив в любую папку (например, `D:\UZFIR_Extractor_APK`).
2. Дважды нажмите на файл **`BUILD_APK_WINDOWS.bat`**.
3. Скрипт сам соберёт `app-release.apk` и автоматически откроет папку с готовым файлом APK!

### Способ Б — Через терминал Android Studio
Откройте папку `flutter_extractor_app` в Android Studio и выполните в терминале:
```powershell
flutter create --platforms=android --org uz.uzfir.extractor --project-name uzfir_db_extractor .
flutter pub get
flutter build apk --release
```
Готовый файл APK появится в `flutter_extractor_app\build\app\outputs\flutter-apk\app-release.apk`.
