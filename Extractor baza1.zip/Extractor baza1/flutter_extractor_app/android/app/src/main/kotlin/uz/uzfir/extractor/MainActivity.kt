package uz.uzfir.extractor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private val CHANNEL = "uz.uzfir.extractor/files"
    private val PICK_FILE_REQ = 4001
    private var pendingPickResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickFile" -> {
                    pendingPickResult = result
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(intent, PICK_FILE_REQ)
                }
                "saveAndShareFile" -> {
                    val filename = call.argument<String>("filename") ?: "export.bin"
                    val bytes = call.argument<ByteArray>("bytes") ?: ByteArray(0)
                    val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                    val share = call.argument<Boolean>("share") ?: false
                    try {
                        val savedPath = saveToDownloads(filename, bytes, mimeType, share)
                        result.success(savedPath)
                    } catch (e: Exception) {
                        result.error("SAVE_ERR", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQ) {
            val res = pendingPickResult
            pendingPickResult = null
            if (res == null) return
            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                val uri = data.data!!
                try {
                    val name = queryFileName(uri) ?: "firmware.bin"
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                    res.success(mapOf("name" to name, "bytes" to bytes))
                } catch (e: Exception) {
                    res.error("READ_ERR", e.message, null)
                }
            } else {
                res.success(null)
            }
        }
    }

    private fun queryFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(idx)
            }
        }
        return uri.lastPathSegment
    }

    private fun saveToDownloads(filename: String, bytes: ByteArray, mimeType: String, shareImmediately: Boolean): String {
        var displayPath = "/storage/emulated/0/Download/UZFIR_Extractor/$filename"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/UZFIR_Extractor")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { it.write(bytes) }
                if (shareImmediately) {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mimeType
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, filename))
                }
                return displayPath
            }
        }
        val outDir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "UZFIR_Extractor")
        if (!outDir.exists()) outDir.mkdirs()
        val outFile = File(outDir, filename)
        FileOutputStream(outFile).use { it.write(bytes) }
        displayPath = outFile.absolutePath
        return displayPath
    }
}
