import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:archive/archive.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const UzfirExtractorApp());
}

class UzfirExtractorApp extends StatefulWidget {
  const UzfirExtractorApp({super.key});

  @override
  State<UzfirExtractorApp> createState() => _UzfirExtractorAppState();
}

class _UzfirExtractorAppState extends State<UzfirExtractorApp> {
  bool isDark = true;
  String lang = 'ru'; // 'ru' or 'uz'

  void toggleTheme() => setState(() => isDark = !isDark);
  void toggleLang() => setState(() => lang = (lang == 'ru' ? 'uz' : 'ru'));

  @override
  Widget build(BuildContext context) {
    final darkTheme = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF070D1F),
      primaryColor: const Color(0xFF00F5D4),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF00F5D4),
        secondary: Color(0xFF00BBF9),
        surface: Color(0xFF111A36),
      ),
      useMaterial3: true,
    );

    final lightTheme = ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: const Color(0xFFF1F5F9),
      primaryColor: const Color(0xFF0284C7),
      colorScheme: const ColorScheme.light(
        primary: Color(0xFF0284C7),
        secondary: Color(0xFF0D9488),
        surface: Colors.white,
      ),
      useMaterial3: true,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UZFIR DB Extractor',
      theme: isDark ? darkTheme : lightTheme,
      home: ExtractorHomePage(
        isDark: isDark,
        lang: lang,
        onToggleTheme: toggleTheme,
        onToggleLang: toggleLang,
      ),
    );
  }
}

class RadarRecord {
  final int id;
  final double lat;
  final double lon;
  final int speed;
  final int speed2;
  final int azimuth;
  final int distance;
  final int camType;
  final String camTypeName;
  final int modelId;
  final String modelCode;
  final String modelName;
  final int flags;
  final String flagsText;
  final bool isBack;
  final bool isBusLane;
  final bool isStopLine;
  final int pairId;
  final String region;
  final int navitelType;

  RadarRecord({
    required this.id,
    required this.lat,
    required this.lon,
    required this.speed,
    required this.speed2,
    required this.azimuth,
    required this.distance,
    required this.camType,
    required this.camTypeName,
    required this.modelId,
    required this.modelCode,
    required this.modelName,
    required this.flags,
    required this.flagsText,
    required this.isBack,
    required this.isBusLane,
    required this.isStopLine,
    required this.pairId,
    required this.region,
    required this.navitelType,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'lat': lat,
        'lon': lon,
        'speed': speed,
        'azimuth': azimuth,
        'distance': distance,
        'type': camTypeName,
        'model_code': modelCode,
        'model': modelName,
        'back': isBack,
        'features': flagsText,
        'region': region,
        'navitel_type': navitelType,
      };
}

class DopplerParser {
  static const Map<int, List<String>> modelTable = {
    0: ['—', 'Не указана'],
    1: ['АС', 'Автодория / Арена-С'],
    2: ['ФФ', 'Фотофиксация'],
    3: ['АР', 'Арена'],
    4: ['АРГС', 'Аргус'],
    5: ['АРКН', 'Аркан'],
    6: ['АСТ', 'Астра-Трафик'],
    7: ['АТОМ', 'Атом ИС'],
    8: ['AUTO', 'Autocon (Автокон)'],
    9: ['АВТД', 'Автодория КСС'],
    10: ['АП', 'Автопатруль'],
    11: ['AVS', 'Автоураган-ВСМ / AVS'],
    12: ['АУ', 'Автоураган'],
    13: ['АЗБР', 'Азимут (Зебра)'],
    14: ['АЗМТ', 'Азимут'],
    15: ['БНР', 'Бинар'],
    16: ['ГРЗ', 'Грузовой контроль'],
    17: ['ДКРТ', 'Декарт'],
    18: ['DP', 'Дорожный Патруль'],
    19: ['ДЗРК', 'Дозор-К'],
    20: ['МОБ', 'Мобильный радар'],
    21: ['ДПС', 'Пост ДПС'],
    22: ['ДПС', 'Пост ДПС / YPX'],
    23: ['EHL', 'Ehlers'],
    24: ['EKIN', 'Ekin Patrol'],
    25: ['ФКТР', 'Фактор'],
    26: ['ФРСЖ', 'Форсаж'],
    27: ['GTS', 'GTS'],
    28: ['ГРОМ', 'Гром'],
    29: ['HKVN', 'Hikvision'],
    30: ['СРГК', 'Сергек (Sergek)'],
    31: ['ИНТ', 'Интегра-КДД'],
    32: ['ИСКР', 'Искра'],
    33: ['КСКД', 'Каскад'],
    34: ['КПРН', 'Коперник'],
    35: ['КРД', 'Кордон (Cordon)'],
    36: ['КРЧ', 'Кречет'],
    37: ['КРИС', 'Крис (Kris)'],
    38: ['ОСТ', 'Контроль остановки'],
    39: ['ЛИДР', 'Лидер'],
    40: ['ЛИСД', 'ЛИСД (Лазер)'],
    41: ['ЛБЧ', 'Лобачевский'],
    42: ['LCHN', 'Lochin (Лочин)'],
    43: ['МГСТ', 'Магистраль'],
    44: ['MEGA', 'Megacam (Мегакам)'],
    45: ['MERG', 'Мерген (Mergen)'],
    46: ['MSTA', 'Mesta'],
    47: ['МETE', 'Метеор'],
    50: ['MRG', 'Мираж'],
    51: ['МЛЖ', 'Муляж радара'],
    52: ['ММ', 'Маломощный радар'],
    53: ['MLTN', 'MultaNova'],
    54: ['MLTR', 'MultaRadar'],
    55: ['МОБ', 'Мобильная засада'],
    56: ['NIKA', 'Ника'],
    57: ['ОДСС', 'Одиссей'],
    58: ['ОРАК', 'Оракул'],
    59: ['ОРЛН', 'Орлан'],
    60: ['ОСКН', 'Оскон'],
    61: ['ПРКН', 'Паркон'],
    62: ['ПАУК', 'Паук'],
    64: ['ПЛТН', 'Платон (Грузовой)'],
    65: ['POI', 'Пользовательская точка'],
    66: ['ПЛСК', 'Полискан (PoliScan)'],
    67: ['ПТК', 'Система Поток'],
    68: ['ПРЗМ', 'Призма'],
    69: ['ПТК', 'Поток-ПДД'],
    70: ['ПТЛМ', 'Птолемей'],
    71: ['ПЛСР', 'Пульсар'],
    72: ['РД', 'Стационарный радар'],
    74: ['RDSP', 'RedSpeed'],
    75: ['ROAD', 'RoadScan'],
    76: ['KEON', 'Keon'],
    78: ['СФКС', 'Сфинкс'],
    80: ['СКАТ', 'Скат (Skat)'],
    81: ['TRFC', 'Traffic'],
    82: ['SOVA', 'Сова'],
    83: ['SPDG', 'SpeedGuard'],
    85: ['SPTR', 'Спектр'],
    86: ['СТРЖ', 'Страж'],
    87: ['СТВБ', 'Стрелка-Видеоблок'],
    88: ['СТ', 'Стрелка-СТ/М'],
    89: ['СТФЛ', 'Стрелка-Фалько'],
    90: ['СТЦ', 'Стационарный радар'],
    93: ['СВТФ', 'Камера светофора'],
    94: ['TRFX', 'Traffipax'],
    95: ['TRFR', 'Traffic Radar'],
    96: ['TRFS', 'Traffic Star'],
    97: ['МОБ', 'Мобильный пост'],
    98: ['TRCM', 'TruCAM (Лазер)'],
    100: ['У-ЮГ', 'Ураган-Юг'],
    101: ['ВБ', 'Видеоблок'],
    102: ['VLTC', 'Vitronic'],
    103: ['ВКРД', 'Вокорд (Vocord)'],
    104: ['ВЗОР', 'Взор'],
    106: ['ZRK2', 'Зоркий-2'],
    107: ['ZND', 'Зонд'],
  };

  static const Map<int, String> cameraTypes = {
    0: 'Маломощный радар / Камера',
    1: 'Стационарный радар',
    2: 'Система Поток',
    3: 'Стрелка',
    5: 'Светофор / Перекресток',
    6: 'Ж/Д переезд',
    7: 'Мобильный радар / Засада',
    10: 'Пост ДПС / YPX',
    11: 'Начало КСС (Средняя скорость)',
    12: 'Видеоблок (Безрадарный)',
    33: 'Грузовой контроль',
    110: 'Конец КСС (Средняя скорость)',
    200: 'Муляж радара',
  };

  static bool isUzbekistan(double lat, double lon) {
    if (lat < 37.15 || lat > 45.60 || lon < 55.95 || lon > 73.15) return false;
    if (lon < 60.0 && lat < 41.2) return false;
    if (lon >= 60.0 && lon < 63.5 && lat < 40.0 - (lon - 60.0) * 0.35) return false;
    if (lon >= 63.5 && lon < 66.5 && lat < 38.8 - (lon - 63.5) * 0.45) return false;
    if (lon >= 68.18 && lat < 39.10) return false;
    if (lon >= 67.45 && lon <= 70.60 && lat >= 39.10 && lat < 40.15) return false;
    if (lon >= 69.35 && lon <= 70.50 && lat >= 40.15 && lat <= 40.50) return false;
    if (lon >= 72.72 && lat <= 40.62) return false;
    if (lon >= 72.88 && lat >= 40.82) return false;
    if (lat > 41.60 && lon > 70.25) return false;
    if (lon >= 68.40 && lat >= 41.45 && !(lon >= 69.05 && lon <= 70.25 && lat <= 41.78)) return false;
    if (lon >= 61.5 && lon < 68.40 && lat > 43.65) return false;
    return true;
  }

  static String detectRegion(double lat, double lon) {
    if (isUzbekistan(lat, lon)) return 'UZ';
    if (lat >= 36.5 && lat <= 46.0 && lon >= 55.5 && lon <= 74.0) return 'CA';
    return 'RU_CIS';
  }

  static int mapNavitelType(int camType, int flags) {
    if (camType == 11 || camType == 110 || (flags & 0x00C0) != 0) return 4;
    if (camType == 5 || (flags & 0x0002) != 0) return 2;
    if (camType == 7 || (flags & 0x2000) != 0) return 5;
    if (camType == 10) return 201;
    if (camType == 6) return 105;
    if (camType == 12) return 3;
    return 1;
  }

  static String decodeFlagsText(int flags) {
    final tags = <String>[];
    if ((flags & 0x0004) != 0) tags.add('В спину');
    if ((flags & 0x0002) != 0) tags.add('Светофор/Стоп-линия');
    if ((flags & 0x0020) != 0) tags.add('Полоса ОТ');
    if ((flags & 0x0008) != 0) tags.add('Пешеходный');
    if ((flags & 0x0001) != 0) tags.add('Обочина');
    if ((flags & 0x0200) != 0) tags.add('Остановка');
    if ((flags & 0x4000) != 0) tags.add('Грузовой');
    if ((flags & 0x0040) != 0) tags.add('Старт КСС');
    if ((flags & 0x0080) != 0) tags.add('Финиш КСС');
    if ((flags & 0x2000) != 0) tags.add('Тренога');
    if ((flags & 0x8000) != 0) tags.add('Ремень/Телефон');
    return tags.isEmpty ? 'Скорость' : tags.join(', ');
  }

  static Map<String, dynamic> parseBytes(Uint8List rawBytes, String fileName) {
    Uint8List data = rawBytes;
    String activeName = fileName;

    // Check if ZIP archive (PK\x03\x04)
    if (data.length > 4 && data[0] == 0x50 && data[1] == 0x4B) {
      final archive = ZipDecoder().decodeBytes(data);
      ArchiveFile? largestBin;
      for (final file in archive) {
        if (file.isFile && file.name.toLowerCase().endsWith('.bin')) {
          if (largestBin == null || file.size > largestBin.size) {
            largestBin = file;
          }
        }
      }
      if (largestBin == null) {
        throw Exception('Внутри ZIP-архива не найден файл .bin');
      }
      data = Uint8List.fromList(largestBin.content as List<int>);
      activeName = largestBin.name.split('/').last;
    }

    final fileSize = data.length;
    int? dbOffset;
    bool isCombo = false;

    if (fileSize >= 32 &&
        data[12] == 0x56 &&
        data[13] == 0x32 &&
        data[14] == 0x2E) {
      dbOffset = 0;
    } else {
      final candidates = <int>[
        0x00900010,
        0x00580010,
        0x0051D010,
        0x00500000,
        0x0041D010,
        0x002FD010
      ];
      if (fileSize > 16) {
        final bd = ByteData.sublistView(data, 1, 13);
        final dbSz = bd.getUint32(8, Endian.little);
        if (dbSz > 0 && dbSz < fileSize) {
          candidates.insert(0, fileSize - dbSz);
        }
      }
      for (final c in candidates) {
        if (c >= 0 &&
            c <= fileSize - 32 &&
            data[c + 12] == 0x56 &&
            data[c + 13] == 0x32 &&
            data[c + 14] == 0x2E) {
          dbOffset = c;
          isCombo = c > 0;
          break;
        }
      }
      if (dbOffset == null) {
        for (int i = 12; i < fileSize - 20; i++) {
          if (data[i] == 0x56 &&
              data[i + 1] == 0x32 &&
              data[i + 2] == 0x2E &&
              data[i + 4] == 0x2C) {
            dbOffset = i - 12;
            isCombo = dbOffset > 0;
            break;
          }
        }
      }
    }

    if (dbOffset == null) {
      throw Exception('Сигнатура базы данных V2.x,DDMMYY не найдена в файле');
    }

    final dbBytes = Uint8List.sublistView(data, dbOffset);
    final headerBd = ByteData.sublistView(dbBytes, 0, 12);
    final gridDiv = headerBd.getUint32(0, Endian.little);
    final idxCount = headerBd.getUint32(4, Endian.little);
    final camCount = headerBd.getUint32(8, Endian.little);

    final verRaw = ascii.decode(dbBytes.sublist(12, 23), allowInvalid: true).trim();
    String dbVersion = verRaw;
    String dbDate = '30.10.2026';
    if (verRaw.contains(',')) {
      final parts = verRaw.split(',');
      dbVersion = parts[0];
      final d = parts[1];
      if (d.length == 6) {
        dbDate = '${d.substring(0, 2)}.${d.substring(2, 4)}.20${d.substring(4, 6)}';
      }
    }

    int recStart = 23 + (idxCount + 1) * 10;
    if (recStart + camCount * 28 > dbBytes.length) {
      recStart = dbBytes.length - camCount * 28;
    }

    final records = <RadarRecord>[];
    final recBd = ByteData.sublistView(dbBytes);
    for (int i = 0; i < camCount; i++) {
      final off = recStart + i * 28;
      if (off + 28 > dbBytes.length) break;
      final lonI = recBd.getInt32(off + 4, Endian.little);
      final latI = recBd.getInt32(off + 8, Endian.little);
      final flags = recBd.getUint32(off + 12, Endian.little);
      final camType = recBd.getUint8(off + 16);
      final spd = recBd.getUint8(off + 17);
      final spd2 = recBd.getUint8(off + 18);
      final az = recBd.getUint16(off + 20, Endian.little);
      final dist = recBd.getUint16(off + 22, Endian.little);
      final pairId = recBd.getUint16(off + 24, Endian.little);
      final modelId = recBd.getUint16(off + 26, Endian.little);

      final lat = (latI / 10000.0 * 10000).round() / 10000.0;
      final lon = (lonI / 10000.0 * 10000).round() / 10000.0;
      final mInfo = modelTable[modelId] ?? ['ID$modelId', 'Модель #$modelId'];
      final cTypeName = cameraTypes[camType] ?? 'Тип $camType';
      final reg = detectRegion(lat, lon);

      records.add(RadarRecord(
        id: i + 1,
        lat: lat,
        lon: lon,
        speed: spd,
        speed2: spd2,
        azimuth: az,
        distance: dist,
        camType: camType,
        camTypeName: cTypeName,
        modelId: modelId,
        modelCode: mInfo[0],
        modelName: mInfo[1],
        flags: flags,
        flagsText: decodeFlagsText(flags),
        isBack: (flags & 0x0004) != 0,
        isBusLane: (flags & 0x0020) != 0,
        isStopLine: (flags & 0x0002) != 0,
        pairId: pairId,
        region: reg,
        navitelType: mapNavitelType(camType, flags),
      ));
    }

    return {
      'filename': activeName,
      'fileSize': fileSize,
      'isCombo': isCombo,
      'dbOffset': dbOffset,
      'dbSize': dbBytes.length,
      'dbVersion': dbVersion,
      'dbDate': dbDate,
      'gridDiv': gridDiv,
      'idxCount': idxCount,
      'camCount': records.length,
      'dbBytes': Uint8List.fromList(dbBytes),
      'records': records,
    };
  }

  static Uint8List buildCustomBinaryDb(
      List<RadarRecord> records, String dbVersion, String dbDate) {
    final items = <Map<String, dynamic>>[];
    for (final r in records) {
      final lonI = (r.lon * 10000).round();
      final latI = (r.lat * 10000).round();
      final gx = (lonI ~/ 200) & 0xFFFF;
      final gy = (latI ~/ 200) & 0xFFFF;
      items.add({'r': r, 'lonI': lonI, 'latI': latI, 'gx': gx, 'gy': gy});
    }
    items.sort((a, b) {
      final cmp = (a['gy'] as int).compareTo(b['gy'] as int);
      return cmp != 0 ? cmp : (a['gx'] as int).compareTo(b['gx'] as int);
    });

    final cells = <Map<String, int>>[];
    for (int i = 0; i < items.length; i++) {
      final gx = items[i]['gx'] as int;
      final gy = items[i]['gy'] as int;
      if (cells.isEmpty ||
          cells.last['gx'] != gx ||
          cells.last['gy'] != gy) {
        cells.add({'gx': gx, 'gy': gy, 'count': 1, 'startIdx': i});
      } else {
        cells.last['count'] = cells.last['count']! + 1;
      }
    }

    final idxCount = cells.length;
    final camCount = items.length;
    final recStart = 23 + (idxCount + 1) * 10;
    final totalSize = recStart + camCount * 28;
    final bytes = Uint8List(totalSize);
    final bd = ByteData.sublistView(bytes);

    bd.setUint32(0, 200, Endian.little);
    bd.setUint32(4, idxCount, Endian.little);
    bd.setUint32(8, camCount, Endian.little);

    final rawDate = dbDate.replaceAll('.', '');
    final d6 = rawDate.length == 8
        ? '${rawDate.substring(0, 4)}${rawDate.substring(6, 8)}'
        : '301026';
    final sig = '$dbVersion,$d6'.padRight(11).substring(0, 11);
    for (int i = 0; i < 11; i++) {
      bytes[12 + i] = sig.codeUnitAt(i);
    }

    for (int c = 0; c < idxCount; c++) {
      final off = 23 + c * 10;
      final cell = cells[c];
      bd.setUint16(off, cell['gx']!, Endian.little);
      bd.setUint16(off + 2, cell['gy']!, Endian.little);
      bd.setUint16(off + 4, cell['count']!, Endian.little);
      bd.setUint32(off + 6, recStart + cell['startIdx']! * 28, Endian.little);
    }

    final sentOff = 23 + idxCount * 10;
    if (idxCount > 0) {
      bd.setUint16(sentOff, cells.last['gx']!, Endian.little);
      bd.setUint16(sentOff + 2, cells.last['gy']!, Endian.little);
    }
    bd.setUint16(sentOff + 4, 0, Endian.little);
    bd.setUint32(sentOff + 6, totalSize, Endian.little);

    for (int i = 0; i < camCount; i++) {
      final off = recStart + i * 28;
      final it = items[i];
      final r = it['r'] as RadarRecord;
      bd.setUint16(off, it['gx'] as int, Endian.little);
      bd.setUint16(off + 2, it['gy'] as int, Endian.little);
      bd.setInt32(off + 4, it['lonI'] as int, Endian.little);
      bd.setInt32(off + 8, it['latI'] as int, Endian.little);
      bd.setUint32(off + 12, r.flags, Endian.little);
      bd.setUint8(off + 16, r.camType);
      bd.setUint8(off + 17, r.speed);
      bd.setUint8(off + 18, r.speed2);
      bd.setUint8(off + 19, 1);
      bd.setUint16(off + 20, r.azimuth, Endian.little);
      bd.setUint16(off + 22, r.distance, Endian.little);
      bd.setUint16(off + 24, r.pairId, Endian.little);
      bd.setUint16(off + 26, r.modelId, Endian.little);
    }
    return bytes;
  }
}

class ExtractorHomePage extends StatefulWidget {
  final bool isDark;
  final String lang;
  final VoidCallback onToggleTheme;
  final VoidCallback onToggleLang;

  const ExtractorHomePage({
    super.key,
    required this.isDark,
    required this.lang,
    required this.onToggleTheme,
    required this.onToggleLang,
  });

  @override
  State<ExtractorHomePage> createState() => _ExtractorHomePageState();
}

class _ExtractorHomePageState extends State<ExtractorHomePage> {
  static const MethodChannel _channel = MethodChannel('uz.uzfir.extractor/files');

  bool isLoading = true;
  String statusMessage = '';
  String loadedFilename = 'uzbekistan_db_30102026.bin';
  String dbVersion = 'V2.2';
  String dbDate = '30.10.2026';
  int dbOffset = 0;
  int dbSize = 0;
  bool isCombo = false;
  Uint8List? rawDbBytes;

  List<RadarRecord> allRecords = [];
  List<RadarRecord> filteredRecords = [];

  String selectedRegion = 'ALL'; // ALL, UZ, CA, RU_CIS
  String selectedModel = 'ALL';
  bool onlyBack = false;
  String searchQuery = '';

  String? lastExportPath;
  String? lastExportFilename;
  String? lastExportPreview;

  @override
  void initState() {
    super.initState();
    _loadBuiltInDatabase();
  }

  String tr(String ru, String uz) => widget.lang == 'ru' ? ru : uz;

  Future<void> _loadBuiltInDatabase() async {
    setState(() {
      isLoading = true;
      statusMessage = tr('Загрузка встроенной базы Узбекистана (30.10.2026)...',
          'O‘rnatilgan O‘zbekiston bazasi yuklanmoqda (30.10.2026)...');
    });
    try {
      final bd = await rootBundle.load('assets/uzbekistan_db_30102026.bin');
      final bytes = bd.buffer.asUint8List();
      _applyParsedData(
          DopplerParser.parseBytes(bytes, 'DopplerPro_UZ_DB301026.bin'));
    } catch (e) {
      setState(() {
        isLoading = false;
        statusMessage = 'Ошибка загрузки: $e';
      });
    }
  }

  void _applyParsedData(Map<String, dynamic> res) {
    allRecords = res['records'] as List<RadarRecord>;
    loadedFilename = res['filename'] as String;
    dbVersion = res['dbVersion'] as String;
    dbDate = res['dbDate'] as String;
    dbOffset = res['dbOffset'] as int;
    dbSize = res['dbSize'] as int;
    isCombo = res['isCombo'] as bool;
    rawDbBytes = res['dbBytes'] as Uint8List;
    _filterRecords();
    setState(() {
      isLoading = false;
      statusMessage = tr(
        'База $dbVersion от $dbDate успешно извлечена (${allRecords.length} точек)',
        '$dbDate dagi $dbVersion baza muvaffaqiyatli ajratildi (${allRecords.length} nuqta)',
      );
    });
  }

  void _filterRecords() {
    final q = searchQuery.trim().toLowerCase();
    filteredRecords = allRecords.where((r) {
      if (selectedRegion != 'ALL' && r.region != selectedRegion) return false;
      if (selectedModel != 'ALL' && r.modelCode != selectedModel) return false;
      if (onlyBack && !r.isBack) return false;
      if (q.isNotEmpty) {
        final match = r.modelName.toLowerCase().contains(q) ||
            r.modelCode.toLowerCase().contains(q) ||
            r.camTypeName.toLowerCase().contains(q) ||
            r.flagsText.toLowerCase().contains(q) ||
            '${r.lat},${r.lon}'.contains(q);
        if (!match) return false;
      }
      return true;
    }).toList();
    setState(() {});
  }

  Future<void> _pickBinOrZipFile() async {
    try {
      final result = await _channel.invokeMethod<Map>('pickFile');
      if (result == null) return;
      final String name = result['name'] as String? ?? 'uploaded.bin';
      final Uint8List bytes = result['bytes'] as Uint8List;
      setState(() {
        isLoading = true;
        statusMessage = tr('Разбор файла $name...', '$name fayli tahlil qilinmoqda...');
      });
      await Future.delayed(const Duration(milliseconds: 50));
      final parsed = DopplerParser.parseBytes(bytes, name);
      _applyParsedData(parsed);
    } catch (e) {
      setState(() {
        isLoading = false;
        statusMessage = tr('Ошибка открытия файла: $e', 'Faylni ochishda xatolik: $e');
      });
    }
  }

  Future<void> _exportFormat(String format, {bool shareImmediately = false}) async {
    if (filteredRecords.isEmpty) return;
    final dateTag = dbDate.replaceAll('.', '');
    final count = filteredRecords.length;
    late Uint8List outBytes;
    late String outName;
    late String mimeType;
    late String previewText;

    if (format == 'bin') {
      if (rawDbBytes != null && count == allRecords.length) {
        outBytes = rawDbBytes!;
      } else {
        outBytes = DopplerParser.buildCustomBinaryDb(filteredRecords, dbVersion, dbDate);
      }
      outName = 'UZFIR_DB_${dateTag}_${count}pts.bin';
      mimeType = 'application/octet-stream';
      final hexStr = outBytes
          .take(24)
          .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
          .join(' ');
      previewText =
          'Чистый бинарный файл базы радаров (_DB.bin)\nРазмер: ${outBytes.length} байт\nСигнатура: $dbVersion,$dateTag\nHEX (0..24): $hexStr';
    } else if (format == 'json') {
      final mapData = {
        'metadata': {
          'source': loadedFilename,
          'db_version': dbVersion,
          'db_date': dbDate,
          'exported_count': count,
        },
        'cameras': filteredRecords.map((r) => r.toJson()).toList(),
      };
      final jsonStr = const JsonEncoder.withIndent('  ').convert(mapData);
      outBytes = Uint8List.fromList(utf8.encode(jsonStr));
      outName = 'UZFIR_Cameras_${dateTag}_${count}pts.json';
      mimeType = 'application/json';
      previewText = jsonStr.length > 600 ? '${jsonStr.substring(0, 600)}\n...' : jsonStr;
    } else if (format == 'txt_navitel') {
      final sb = StringBuffer('IDX,X,Y,TYPE,SPEED,DIRTYPE,DIRECTION\r\n');
      for (int i = 0; i < filteredRecords.length; i++) {
        final r = filteredRecords[i];
        sb.write(
            '${i + 1},${r.lon.toStringAsFixed(4)},${r.lat.toStringAsFixed(4)},${r.navitelType},${r.speed},1,${r.azimuth}\r\n');
      }
      final txt = sb.toString();
      outBytes = Uint8List.fromList(utf8.encode(txt));
      outName = 'SpeedCam_Navitel_ContraCam_${dateTag}_${count}pts.txt';
      mimeType = 'text/plain';
      previewText = txt.length > 500 ? '${txt.substring(0, 500)}\n...' : txt;
    } else if (format == 'txt_igo') {
      final sb = StringBuffer('X,Y,TYPE,SPEED,DIRTYPE,DIRECTION\r\n');
      for (final r in filteredRecords) {
        sb.write(
            '${r.lon.toStringAsFixed(4)},${r.lat.toStringAsFixed(4)},${r.navitelType},${r.speed},1,${r.azimuth}\r\n');
      }
      final txt = sb.toString();
      outBytes = Uint8List.fromList(utf8.encode(txt));
      outName = 'SpeedCam_iGO_${dateTag}_${count}pts.txt';
      mimeType = 'text/plain';
      previewText = txt.length > 500 ? '${txt.substring(0, 500)}\n...' : txt;
    } else if (format == 'csv') {
      final sb = StringBuffer(
          '\uFEFFid,lat,lon,speed,azimuth,distance,model_code,model_name,cam_type,features,is_back,region,navitel_type\r\n');
      for (final r in filteredRecords) {
        sb.write(
            '${r.id},${r.lat.toStringAsFixed(4)},${r.lon.toStringAsFixed(4)},${r.speed},${r.azimuth},${r.distance},"${r.modelCode}","${r.modelName}","${r.camTypeName}","${r.flagsText}",${r.isBack},${r.region},${r.navitelType}\r\n');
      }
      final txt = sb.toString();
      outBytes = Uint8List.fromList(utf8.encode(txt));
      outName = 'UZFIR_Cameras_Full_${dateTag}_${count}pts.csv';
      mimeType = 'text/csv';
      previewText = txt.length > 500 ? '${txt.substring(0, 500)}\n...' : txt;
    } else if (format == 'gpx') {
      final sb = StringBuffer(
          '<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="UZFIR DB Extractor" xmlns="http://www.topografix.com/GPX/1/1">\n');
      for (final r in filteredRecords) {
        final backStr = r.isBack ? ' [В СПИНУ]' : '';
        final name = '${r.modelName} ${r.speed} км/ч$backStr'
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;');
        final desc =
            '${r.camTypeName} | Азимут: ${r.azimuth}° | Дист: ${r.distance} м | ${r.flagsText}'
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;');
        sb.write(
            '  <wpt lat="${r.lat.toStringAsFixed(4)}" lon="${r.lon.toStringAsFixed(4)}"><name>$name</name><desc>$desc</desc></wpt>\n');
      }
      sb.write('</gpx>');
      final txt = sb.toString();
      outBytes = Uint8List.fromList(utf8.encode(txt));
      outName = 'UZFIR_OsmAnd_${dateTag}_${count}pts.gpx';
      mimeType = 'application/gpx+xml';
      previewText = txt.length > 500 ? '${txt.substring(0, 500)}\n...' : txt;
    } else {
      final sb = StringBuffer(
          '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>\n');
      for (final r in filteredRecords) {
        final name = '${r.modelName} (${r.speed} км/ч)'
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;');
        sb.write(
            '  <Placemark><name>$name</name><Point><coordinates>${r.lon.toStringAsFixed(4)},${r.lat.toStringAsFixed(4)},0</coordinates></Point></Placemark>\n');
      }
      sb.write('</Document></kml>');
      final txt = sb.toString();
      outBytes = Uint8List.fromList(utf8.encode(txt));
      outName = 'UZFIR_MapsMe_${dateTag}_${count}pts.kml';
      mimeType = 'application/vnd.google-earth.kml+xml';
      previewText = txt.length > 500 ? '${txt.substring(0, 500)}\n...' : txt;
    }

    try {
      final savedPath = await _channel.invokeMethod<String>('saveAndShareFile', {
        'filename': outName,
        'bytes': outBytes,
        'mimeType': mimeType,
        'share': shareImmediately,
      });
      setState(() {
        lastExportFilename = outName;
        lastExportPath = savedPath ?? '/storage/emulated/0/Download/UZFIR_Extractor/$outName';
        lastExportPreview = previewText;
        statusMessage = tr(
          'Сохранено в Загрузки: $outName (${(outBytes.length / 1024).toStringAsFixed(1)} КБ)',
          'Yuklamalarga saqlandi: $outName (${(outBytes.length / 1024).toStringAsFixed(1)} KB)',
        );
      });
    } catch (e) {
      setState(() {
        lastExportFilename = outName;
        lastExportPreview = previewText;
        statusMessage = 'Экспорт готов: $outName';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final uzCount = allRecords.where((r) => r.region == 'UZ').length;
    final backCount = filteredRecords.where((r) => r.isBack).length;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: widget.isDark ? const Color(0xFF0E172E) : Colors.white,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF00F5D4).withOpacity(0.18),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF00F5D4).withOpacity(0.5)),
              ),
              child: const Text(
                'UZFIR APK',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF00F5D4),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                tr('Извлечение баз BIN / JSON / TXT', 'BIN / JSON / TXT Baza Ajratish'),
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: widget.onToggleLang,
            child: Text(
              widget.lang.toUpperCase(),
              style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF00F5D4)),
            ),
          ),
          IconButton(
            onPressed: widget.onToggleTheme,
            icon: Icon(widget.isDark ? Icons.light_mode : Icons.dark_mode),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                // Status Card & Open File button
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: widget.isDark ? const Color(0xFF111A36) : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF00F5D4).withOpacity(0.35)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        statusMessage,
                        style: const TextStyle(
                          color: Color(0xFF00F5D4),
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${tr("Файл", "Fayl")}: $loadedFilename  •  ${tr("Версия БД", "Baza versiyasi")}: $dbVersion ($dbDate)',
                        style: TextStyle(
                          fontSize: 12,
                          color: widget.isDark ? Colors.white70 : Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF00F5D4),
                                foregroundColor: const Color(0xFF070D1F),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: _pickBinOrZipFile,
                              icon: const Icon(Icons.folder_open),
                              label: Text(
                                tr('Открыть .BIN или .ZIP с телефона',
                                    'Telefondan .BIN yoki .ZIP ochish'),
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // KPI Cards
                Row(
                  children: [
                    _buildKpiCard(
                      tr('Выбрано точек', 'Tanlangan nuqtalar'),
                      '${filteredRecords.length}',
                      const Color(0xFF00F5D4),
                    ),
                    const SizedBox(width: 8),
                    _buildKpiCard(
                      tr('Узбекистан', 'O‘zbekiston'),
                      '$uzCount',
                      const Color(0xFF00BBF9),
                    ),
                    const SizedBox(width: 8),
                    _buildKpiCard(
                      tr('В спину', 'Orqaga'),
                      '$backCount',
                      const Color(0xFFF59E0B),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Filters Card
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: widget.isDark ? const Color(0xFF111A36) : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tr('Фильтр региона и модели перед экспортом',
                            'Eksport oldidan hudud va model filtri'),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const SizedBox(height: 10),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            _buildRegionChip('ALL', tr('Все (${allRecords.length})', 'Barchasi')),
                            const SizedBox(width: 8),
                            _buildRegionChip('UZ', tr('Узбекистан ($uzCount)', 'O‘zbekiston')),
                            const SizedBox(width: 8),
                            _buildRegionChip('CA', tr('Центр. Азия', 'Markaziy Osiyo')),
                            const SizedBox(width: 8),
                            _buildRegionChip('RU_CIS', tr('Россия и СНГ', 'Rossiya va MDH')),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        decoration: InputDecoration(
                          hintText: tr('Поиск (Hikvision, Lochin, Автоураган, 60...)',
                              'Qidiruv (Hikvision, Lochin, Avtouragan, 60...)'),
                          prefixIcon: const Icon(Icons.search),
                          isDense: true,
                          filled: true,
                          fillColor: widget.isDark
                              ? const Color(0xFF070D1F)
                              : const Color(0xFFF1F5F9),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (v) {
                          searchQuery = v;
                          _filterRecords();
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Export Buttons Grid (BIN, JSON, TXT, CSV, GPX, KML)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: widget.isDark ? const Color(0xFF111A36) : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF00BBF9).withOpacity(0.35)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tr('Экспорт базы в память телефона (Download/UZFIR_Extractor)',
                            'Bazani telefon xotirasiga eksport qilish'),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const SizedBox(height: 10),
                      GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 8,
                        crossAxisSpacing: 8,
                        childAspectRatio: 2.6,
                        children: [
                          _buildExportBtn(
                            'BIN (Чистая база)',
                            'Без прошивки и голоса',
                            const Color(0xFF10B981),
                            () => _exportFormat('bin'),
                          ),
                          _buildExportBtn(
                            'JSON (Структура)',
                            'Для сервера и Android',
                            const Color(0xFF00BBF9),
                            () => _exportFormat('json'),
                          ),
                          _buildExportBtn(
                            'TXT (SpeedCam)',
                            'Navitel / ContraCam / HUD',
                            const Color(0xFF3B82F6),
                            () => _exportFormat('txt_navitel'),
                          ),
                          _buildExportBtn(
                            'CSV (Таблица Excel)',
                            'Все 15 полей и модели',
                            const Color(0xFF8B5CF6),
                            () => _exportFormat('csv'),
                          ),
                          _buildExportBtn(
                            'TXT (iGO Primo)',
                            'Формат iGO / Антирадар',
                            const Color(0xFF6366F1),
                            () => _exportFormat('txt_igo'),
                          ),
                          _buildExportBtn(
                            'GPX / KML (Карты)',
                            'OsmAnd / Organic Maps',
                            const Color(0xFFF59E0B),
                            () => _exportFormat('gpx'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF00F5D4),
                            side: const BorderSide(color: Color(0xFF00F5D4)),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () => _exportFormat('json', shareImmediately: true),
                          icon: const Icon(Icons.share),
                          label: Text(
                            tr('Поделиться файлом базы (Telegram / Файлы)',
                                'Baza faylini ulashish (Telegram / Fayllar)'),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                if (lastExportFilename != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF064E3B).withOpacity(0.45),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF10B981)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '✅ ${tr("Готово", "Tayyor")}: $lastExportFilename',
                          style: const TextStyle(
                            color: Color(0xFF34D399),
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        if (lastExportPath != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              'Путь в телефоне: $lastExportPath',
                              style: const TextStyle(fontSize: 11, color: Colors.white70),
                            ),
                          ),
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            lastExportPreview ?? '',
                            style: const TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 11,
                              color: Colors.greenAccent,
                            ),
                            maxLines: 8,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 12),
                // Preview list of first 50 cameras
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: widget.isDark ? const Color(0xFF111A36) : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tr('Предпросмотр точек камеры (первые 50 из ${filteredRecords.length})',
                            'Kamera nuqtalarini ko‘rish (dastlabki 50 ta)'),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const SizedBox(height: 8),
                      ...filteredRecords.take(50).map(
                            (r) => Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              decoration: BoxDecoration(
                                color: widget.isDark
                                    ? const Color(0xFF070D1F)
                                    : const Color(0xFFF8FAFC),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 38,
                                    height: 38,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: Colors.redAccent, width: 2.5),
                                    ),
                                    child: Text(
                                      '${r.speed}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${r.modelName} (${r.modelCode}) • ${r.region}',
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13),
                                        ),
                                        Text(
                                          '${r.lat.toStringAsFixed(4)}, ${r.lon.toStringAsFixed(4)} • Азимут: ${r.azimuth}° • ${r.flagsText}',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: widget.isDark
                                                ? Colors.white60
                                                : Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildKpiCard(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
          color: widget.isDark ? const Color(0xFF111A36) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.4)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: color,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(fontSize: 10, color: Colors.grey),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRegionChip(String code, String label) {
    final active = selectedRegion == code;
    return ChoiceChip(
      label: Text(label),
      selected: active,
      onSelected: (_) {
        selectedRegion = code;
        _filterRecords();
      },
    );
  }

  Widget _buildExportBtn(
      String title, String sub, Color color, VoidCallback onTap) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color.withOpacity(0.18),
        foregroundColor: color,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: color.withOpacity(0.55)),
        ),
      ),
      onPressed: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
                  const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
          Text(sub,
              style: TextStyle(fontSize: 10, color: color.withOpacity(0.85)),
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
